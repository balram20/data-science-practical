# Actual practical ke time pe error tum khud solve krlo
